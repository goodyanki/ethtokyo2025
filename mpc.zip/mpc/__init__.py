"""
MPC package marker. Enables relative imports like `.payment` when running
via `uvicorn mpc.server:app` or `python -m mpc.server`.
"""

