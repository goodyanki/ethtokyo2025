# mpc/scanner.py
# -*- coding: utf-8 -*-
import os, time, sqlite3, hashlib
from typing import List, Tuple, Optional
from web3 import Web3

# ======================================================================
# 环境配置
# ======================================================================
DB_PATH         = os.getenv("DB_PATH", "mpc_index.db")
USER_ID         = os.getenv("USER_ID", "alice")
TARGET_ADDRESS  = os.getenv("TARGET_ADDRESS", "0x70997970C51812dc3A010C7d01b50e0d17dc79C8")
# SCAN_CODEC: "x32"（默认，与前端一致），"comp33"（压缩点33B），"auto"（两种都试）
SCAN_CODEC      = os.getenv("SCAN_CODEC", "x32").lower()

# ======================================================================
# 工具函数
# ======================================================================
SECP_N = int("0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141", 16)

def _strip0x(s: str) -> str:
    return s[2:] if isinstance(s, str) and s.lower().startswith("0x") else s

def _b2h(b: bytes) -> str:
    return "0x" + (b.hex() if isinstance(b, (bytes, bytearray)) else bytes(b).hex())

def _as_bytes(x) -> bytes:
    """尽量把各种形态（bytes/HexBytes/str/内存视图）转成原始 bytes，用于比较/计算。"""
    if x is None:
        return b""
    if isinstance(x, (bytes, bytearray)):
        return bytes(x)
    if isinstance(x, memoryview):
        return bytes(x)
    if isinstance(x, str):
        s = x.strip()
        if s.lower().startswith("0x"):
            s = s[2:]
        try:
            return bytes.fromhex(s)
        except Exception:
            return s.encode("utf-8", "ignore")
    # 兜底
    try:
        return bytes(x)
    except Exception:
        return b""

# ======================================================================
# View 私钥派生（与前端 receiveCode.js/derivePubkeysFromAddress 完全一致）
# ======================================================================
def derive_view_private_key(address: str) -> str:
    addr_lower = address.lower()
    seed_view = Web3.keccak(text=addr_lower + ":view")       # 32B
    seed_int  = int.from_bytes(seed_view, "big")
    view_sk_int = (seed_int % (SECP_N - 1)) + 1              # [1, n-1]
    return f"0x{view_sk_int:064x}"

VIEW_PRIVATE_KEY = derive_view_private_key(TARGET_ADDRESS)

print(f"[scanner] Scanning for user: {USER_ID}")
print(f"[scanner] Target address: {TARGET_ADDRESS}")
print(f"[scanner] View private key: {VIEW_PRIVATE_KEY[:10]}... (derived)")

# ======================================================================
# TAG 计算（默认 X(32B)；可选 comp33；或 auto 双口径兼容）
# ======================================================================
def _tag_from_shared_x32(R_bytes: bytes, view_sk_hex: str) -> bytes:
    """
    与前端一致：
    shared_pt = (view_sk * R)   # 椭圆曲线点
    x32 = X(shared_pt)          # 取 32B X 坐标
    tag = keccak256( sha256(x32) )
    """
    from coincurve import PrivateKey, PublicKey
    sk = PrivateKey.from_hex(_strip0x(view_sk_hex))
    R  = PublicKey(R_bytes)                          # 33B 压缩公钥（0x02/0x03..）
    shared_pt = R.multiply(sk.secret)
    uncompressed = shared_pt.format(compressed=False)  # 65B: 0x04||X(32)||Y(32)
    x32 = uncompressed[1:33]
    return Web3.keccak(hashlib.sha256(x32).digest())

def _tag_from_shared_comp33(R_bytes: bytes, view_sk_hex: str) -> bytes:
    """
    兼容用：对共享点的压缩形式(33B)做 sha256→keccak
    """
    from coincurve import PrivateKey, PublicKey
    sk = PrivateKey.from_hex(_strip0x(view_sk_hex))
    R  = PublicKey(R_bytes)
    comp33 = R.multiply(sk.secret).format(compressed=True)   # 33B
    return Web3.keccak(hashlib.sha256(comp33).digest())

def derive_tag(R_bytes: bytes, view_sk_hex: str) -> Tuple[bytes, Optional[bytes], str]:
    """
    返回：(tag_primary, tag_secondary_or_None, codec_used)
    - 当 SCAN_CODEC='x32'：仅算 x32
    - 当 SCAN_CODEC='comp33'：仅算 comp33
    - 当 SCAN_CODEC='auto'：先算 x32，再算 comp33（用于迁移期兼容）
    """
    codec = SCAN_CODEC
    if codec == "x32":
        return _tag_from_shared_x32(R_bytes, view_sk_hex), None, "x32"
    elif codec == "comp33":
        return _tag_from_shared_comp33(R_bytes, view_sk_hex), None, "comp33"
    else:  # auto
        t1 = _tag_from_shared_x32(R_bytes, view_sk_hex)
        t2 = _tag_from_shared_comp33(R_bytes, view_sk_hex)
        return t1, t2, "auto"

# ======================================================================
# 数据库
# ======================================================================
def ensure_tables():
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    # watcher 会创建 events，这里也兜底一份最小结构，避免空库报错
    cur.execute("""
    CREATE TABLE IF NOT EXISTS events(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      block INTEGER,
      txhash TEXT,
      tag BLOB,
      R   BLOB,
      memo BLOB,
      commitment BLOB,
      scanned INTEGER DEFAULT 0,
      matched INTEGER DEFAULT 0,
      created_at INTEGER
    )""")
    cur.execute("""
    CREATE TABLE IF NOT EXISTS inbox(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT,
      event_id INTEGER,
      tag BLOB,
      R   BLOB,
      memo BLOB,
      commitment BLOB,
      status TEXT DEFAULT 'unread',
      detected_at INTEGER
    )""")
    con.commit()
    con.close()

def fetch_unscanned() -> List[Tuple]:
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("SELECT id, tag, R, memo, commitment FROM events WHERE scanned=0")
    rows = cur.fetchall()
    con.close()
    return rows

def mark_scanned(eid: int, matched: int):
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("UPDATE events SET scanned=1, matched=? WHERE id=?", (matched, eid))
    con.commit()
    con.close()

def insert_inbox(user_id: str, eid: int, tag: bytes, R: bytes, memo: bytes, commitment: bytes):
    con = sqlite3.connect(DB_PATH)
    cur = con.cursor()
    cur.execute("""
      INSERT INTO inbox(user_id, event_id, tag, R, memo, commitment, detected_at)
      VALUES(?,?,?,?,?,?, strftime('%s','now'))
    """, (user_id, eid, tag, R, memo, commitment))
    con.commit()
    con.close()

# ======================================================================
# 扫描一次
# ======================================================================
def scan_once():
    ensure_tables()
    pending = fetch_unscanned()
    if not pending:
        print("[scanner] no pending events")
        return

    for eid, tag_b, R_b, memo_b, commitment_b in pending:
        try:
            tag_db = _as_bytes(tag_b)
            R_raw  = _as_bytes(R_b)
            memo_b = _as_bytes(memo_b) if memo_b is not None else b""
            commitment_b = _as_bytes(commitment_b) if commitment_b is not None else b""

            # 只接受 33B 压缩公钥（首字节 0x02/0x03）
            if len(R_raw) != 33 or R_raw[0] not in (2, 3):
                print(f"[scanner] ⚠️  eid={eid} unexpected R length/prefix: len={len(R_raw)} first={R_raw[:1].hex()}")
                mark_scanned(eid, 0)
                continue

            tag_primary, tag_secondary, codec_used = derive_tag(R_raw, VIEW_PRIVATE_KEY)

            # 调试对照
            dbg = f"[scanner] eid={eid} R_len={len(R_raw)} codec={codec_used} " \
                  f"tag_db={_b2h(tag_db)} tag_calc={_b2h(tag_primary)}"
            if codec_used == "auto":
                dbg += f" tag_calc_alt={_b2h(tag_secondary)}"
            print(dbg)

            matched = 0
            if tag_primary == tag_db:
                matched = 1
            elif tag_secondary is not None and tag_secondary == tag_db:
                matched = 1

            if matched:
                insert_inbox(USER_ID, eid, tag_db, R_raw, memo_b, commitment_b)
                mark_scanned(eid, 1)
                print(f"[scanner] ✅ MATCH event #{eid} -> inbox[{USER_ID}]")
            else:
                mark_scanned(eid, 0)
                print(f"[scanner] ❌ No match event #{eid}")

        except KeyboardInterrupt:
            raise
        except Exception as e:
            print(f"[scanner] error on event {eid}: {e}")
            mark_scanned(eid, 0)

# ======================================================================
# 主程序
# ======================================================================
def main():
    print(f"🔍 [scanner] Starting scanner for {USER_ID}")
    print(f"🎯 Target address: {TARGET_ADDRESS}")
    print(f"🔑 View private key: {VIEW_PRIVATE_KEY[:10]}...")
    print(f"💾 Database: {DB_PATH}")
    print(f"🧮 TAG codec: {SCAN_CODEC} (x32 recommended)")

    ensure_tables()
    print("🚀 Scanner started, monitoring for matching events...")
    while True:
        try:
            scan_once()
        except KeyboardInterrupt:
            print("\n👋 Scanner stopped")
            break
        except Exception as e:
            print(f"❌ [scanner] error: {e}")
        time.sleep(2)

if __name__ == "__main__":
    main()
